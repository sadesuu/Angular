import { Component } from '@angular/core';

@Component({
  selector: 'app-http-client',
  imports: [],
  templateUrl: './http-client.html',
  styleUrl: './http-client.css',
})
export class HttpClient {

}
