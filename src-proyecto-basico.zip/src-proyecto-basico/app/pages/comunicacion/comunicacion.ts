import { Component } from '@angular/core';

@Component({
  selector: 'app-comunicacion',
  imports: [],
  templateUrl: './comunicacion.html',
  styleUrl: './comunicacion.css',
})
export class Comunicacion {

}
