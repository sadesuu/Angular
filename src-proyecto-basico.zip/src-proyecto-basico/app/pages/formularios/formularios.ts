import { Component } from '@angular/core';

@Component({
  selector: 'app-formularios',
  imports: [],
  templateUrl: './formularios.html',
  styleUrl: './formularios.css',
})
export class Formularios {

}
